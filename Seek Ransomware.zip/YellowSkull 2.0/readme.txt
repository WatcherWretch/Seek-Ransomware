Malware name: Seek
Type: Ransomware
Version: 2.0 (Scorpion 1.0 style but also overwrite mbr and can't be unlocked)
Damage rate: Destructive
made in: A Restyle Of Yellowskull
Inspired by: Scorpion Virus, Death Virus.exe, blue_skull.exe, And YellowSkull.exe
made by: Happyfiles
Warning: This Malware is destructive and overwrite MBR run it only on vm and don't use the code for cybercrime or cyberweapon purposes
THE CREATOR IS NOT RESPONSIBLE FOR ANY DAMAGES DONE TO YOUR PC, IF YOUR DEVICE IS DAMAGED, IT IS NOT MY FAULT, IT'S YOUR RESPONISBLY OF
RUNNING THIS RANSOMWARE