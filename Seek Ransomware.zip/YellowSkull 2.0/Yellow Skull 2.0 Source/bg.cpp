#include <Windows.h>

int main(){
	PlaySound("bg.wav", NULL, SND_LOOP | SND_ASYNC);
	Sleep(-1);
}
